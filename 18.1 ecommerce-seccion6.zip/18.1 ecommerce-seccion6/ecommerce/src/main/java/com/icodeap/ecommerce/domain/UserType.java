package com.icodeap.ecommerce.domain;

public enum UserType {
    ADMIN, USER
}
